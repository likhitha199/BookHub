package com.likura.bookhub.activity

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.AsyncTask
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*
import androidx.appcompat.widget.Toolbar
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.room.Room
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.likura.bookhub.R
import com.likura.bookhub.database.BookDatabase
import com.likura.bookhub.database.BookEntity
import com.likura.bookhub.model.Book
import com.likura.bookhub.util.ConnectionManager
import com.squareup.picasso.Picasso
import org.json.JSONObject
import org.w3c.dom.Text
import java.lang.Exception

class DescriptionActivity : AppCompatActivity() {
    lateinit var txtBookName: TextView
    lateinit var txtBookAuthor: TextView
    lateinit var txtBookPrice: TextView
    lateinit var txtBookRating: TextView
    lateinit var imgBookImage: ImageView
    lateinit var txtBookDesc: TextView
    lateinit var btnAddToFav: Button
    lateinit var progressBar: ProgressBar
    lateinit var progressLayout: RelativeLayout
    lateinit var toolbar: Toolbar
    var bookId: String? = "100"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.description_activity)
        txtBookName = findViewById(R.id.txtBookName)
        txtBookAuthor = findViewById(R.id.txtBookAuthor)
        txtBookPrice = findViewById(R.id.txtBookPrice)
        txtBookRating = findViewById(R.id.txtBookRating)
        imgBookImage = findViewById(R.id.imgBookImage)
        txtBookDesc = findViewById(R.id.txtBookDesc)
        btnAddToFav = findViewById(R.id.btnAddToFav)
        progressBar = findViewById(R.id.progressBar)
        progressLayout = findViewById(R.id.progressLayout)
        progressBar.visibility = View.VISIBLE
        progressLayout.visibility = View.VISIBLE   //progress bar and layout are visible until data loads
        toolbar=findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.title="Book Details"

        if (intent != null) {
            bookId = intent.getStringExtra("book_id")
        } else {
            finish()
            Toast.makeText(this@DescriptionActivity, "Some error occured", Toast.LENGTH_SHORT)
                .show()
        }
        if (bookId == "100") {
            finish()
            Toast.makeText(this@DescriptionActivity, "Some error occured", Toast.LENGTH_SHORT)
                .show()
        }
        val queue = Volley.newRequestQueue(this@DescriptionActivity) //sends request to server
        val url = "http://13.235.250.119/v1/book/get_book/"
        val jsonParams = JSONObject()
        jsonParams.put("book_id", bookId) //here name is key used for fetching value bookId
        if(ConnectionManager().checkConnectivity(this@DescriptionActivity))
        {
            val jsonRequest=
                object:JsonObjectRequest(Request.Method.POST, url, jsonParams, Response.Listener {
                    try {
                        val success = it.getBoolean("success")
                        if (success) {
                            val bookJsonObject = it.getJSONObject("book_data")
                            progressLayout.visibility = View.GONE
                            val bookImageUrl =bookJsonObject.getString("image")
                            Picasso.get().load(bookJsonObject.getString("image")).error(R.drawable.default_book_cover).into(imgBookImage)
                            txtBookName.text = bookJsonObject.getString("name")
                            txtBookAuthor.text = bookJsonObject.getString("author")
                            txtBookPrice.text = bookJsonObject.getString("price")
                            txtBookRating.text = bookJsonObject.getString("rating")
                            txtBookDesc.text = bookJsonObject.getString("description")

                            val bookEntity = BookEntity(
                            bookId?.toInt() as Int,
                            txtBookName.text.toString(),
                                txtBookAuthor.text.toString(),
                                txtBookPrice.text.toString(),
                                txtBookRating.text.toString(),
                                txtBookDesc.text.toString(),
                                bookImageUrl

                            )

                            val checkFav =DBAsyncTask(applicationContext,bookEntity,1).execute()
                            val isFav= checkFav.get()
                            if(isFav)
                            {
                                btnAddToFav.text="Remove from Favourites"
                                val favColor =ContextCompat.getColor(applicationContext,R.color.colorFavorite)
                                btnAddToFav.setBackgroundColor(favColor)
                            }
                            else{
                                btnAddToFav.text="Add to Favourites"
                                val noFavColor=ContextCompat.getColor(applicationContext,R.color.colorPrimary)
                                btnAddToFav.setBackgroundColor(noFavColor)
                            }

                            btnAddToFav.setOnClickListener {

                                if(!DBAsyncTask(applicationContext,bookEntity,1).execute().get()) {
                                    val async =DBAsyncTask(applicationContext,bookEntity,2).execute()
                                    val result=async.get()
                                    if(result)
                                    {
                                        Toast.makeText(
                                            this@DescriptionActivity,
                                            "Book added to favourites",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                        btnAddToFav.text="Remove from favourites"
                                        val favColor =ContextCompat.getColor(applicationContext,R.color.colorFavorite)
                                        btnAddToFav.setBackgroundColor(favColor)
                                    }
                                    else{
                                        Toast.makeText(
                                            this@DescriptionActivity,
                                            "Some error occured!",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                }
                                else{
                                    val async=DBAsyncTask(applicationContext,bookEntity,3).execute()
                                    val result=async.get()
                                    if(result)
                                    {
                                        Toast.makeText(
                                            this@DescriptionActivity,
                                            "Book removed from favourites",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                        btnAddToFav.text="Add to Favourites"
                                        val noFavColor=ContextCompat.getColor(applicationContext,R.color.colorPrimary)
                                        btnAddToFav.setBackgroundColor(noFavColor)
                                    }
                                    else{
                                        Toast.makeText(
                                            this@DescriptionActivity,
                                            "Some error occured!",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }


                                }

                            }

                        } else {
                            Toast.makeText(
                                this@DescriptionActivity,
                                "Some Error Occured!",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    } catch (e: Exception) {

                        Toast.makeText(
                            this@DescriptionActivity,
                            "Some Error Occured!",
                            Toast.LENGTH_SHORT
                        ).show()

                    }


                }, Response.ErrorListener {
                    Toast.makeText(this@DescriptionActivity, "Volley Error $it", Toast.LENGTH_SHORT)
                        .show()
                }) {
                    override fun getHeaders(): MutableMap<String, String> {
                        val headers =
                            HashMap<String, String>()          //headers are used to tell the type of content that is sent
                        headers["Content-Type"] = "application/json"     // sends key
                        headers["token"] = "1679a479e5171a"          // sends value
                        return headers                 //hash map is derived from mutable map

                    }


                }
            queue.add(jsonRequest)

        }
        else{
            val dialog= AlertDialog.Builder(this@DescriptionActivity)
            dialog.setTitle("Error")
            dialog.setMessage("Internet not found")
            dialog.setPositiveButton("Open Settings"){
                    text,Listener ->
                val settingsIntent= Intent(Settings.ACTION_WIRELESS_SETTINGS) //opens settings on our phone
                startActivity(settingsIntent)
                finish()
            }
            dialog.setNegativeButton("Exit")
            {
                    text,Listener ->
                ActivityCompat.finishAffinity(this@DescriptionActivity) //It closes the app

            }
            dialog.create()
            dialog.show()

        }

    }


    class DBAsyncTask(val context:Context, val bookEntity: BookEntity ,val mode:Int): AsyncTask<Void, Void, Boolean>(){ // It is used to perform multiple db operations at a time
        //context is used to understand which part of app made request

        /*
        Mode 1-> Check Db if book is favourite or not
        Mode 2-> Save Book to favorites
        Mode 3-> Remove book to favourites
        */
        val db = Room.databaseBuilder(context, BookDatabase::class.java, "books-db").build() // We can now use db to perform db operations
        override fun doInBackground(vararg params: Void?): Boolean {

            when(mode)
            {
                1 ->{
                   // Check Db if book is favourite or not
                    val book:BookEntity? =db.bookDao().getBookById(bookEntity.book_id.toString())
                    db.close() //closing is important to avoid unneccesary wastage of memory
                    return book !=null
                }


                2 ->{
                    //  Save Book to favorites
                    db.bookDao().insertBook(bookEntity)
                    db.close()
                    return true
                }


                3 ->{
                    //  Remove book to favourites
                    db.bookDao().deleteBook(bookEntity)
                    db.close()
                    return true
                }

            }
          return false
        }

    }
}
