package com.likura.bookhub.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
//import androidx.appcompat.view.menu.MenuView
import androidx.recyclerview.widget.RecyclerView
import com.likura.bookhub.R
import com.likura.bookhub.activity.DescriptionActivity
import com.likura.bookhub.model.Book
import com.squareup.picasso.Picasso

import java.util.ArrayList


class DashBoardRecyclerAdapter(val context: Context ,val itemList: ArrayList<Book>): RecyclerView.Adapter<DashBoardRecyclerAdapter.DashBoardViewHolder>(){ //context,itemList are primary constructors
    //view in ViewHolder method is view of single row created in recycler_dashboard_single_row
    class DashBoardViewHolder(view: View): RecyclerView.ViewHolder(view)
    {
        val txtBookName:TextView =view.findViewById(R.id.txtBookName) //Creates view Holder for holding lists
        val txtBookAuthor:TextView=view.findViewById(R.id.txtBookAuthor)
        val txtBookPrice:TextView=view.findViewById(R.id.txtBookPrice)
        val txtBookRating:TextView=view.findViewById(R.id.txtBookRating)
        val imgBookImage:ImageView=view.findViewById(R.id.imgBookImage)
          val llContent:LinearLayout=view.findViewById(R.id.llContent)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DashBoardViewHolder {
        //It is responsible for creating the first few viewholders(lists) we see on screen
        val view= LayoutInflater.from(parent.context).inflate(R.layout.recycler_dashboard_single_row,parent,false) //It inflates single layout of one of items and return view holder
         return DashBoardViewHolder(view)
    }

    override fun getItemCount(): Int {
       return itemList.size //returns the size of length of array itemList
    }

    override fun onBindViewHolder(holder: DashBoardViewHolder, position: Int) {  //This method recycles and reuses the view holders
        val book=itemList[position]
        holder.txtBookName.text=book.bookName
        holder.txtBookAuthor.text=book.bookAuthor
        holder.txtBookPrice.text=book.bookPrice
        holder.txtBookRating.text=book.bookRating
        //holder.imgBookImage.setImageResource(book.bookImage)
        Picasso.get().load(book.bookImage).error(R.drawable.default_book_cover).into(holder.imgBookImage)
        holder.llContent.setOnClickListener{
           val intent=Intent(context,DescriptionActivity::class.java) //context refers to the DashboardActivity
            //It navigates to the Description Activity from Dashboard Fragment
            intent.putExtra("book_id",book.bookId)
            context.startActivity(intent) //Start activity opens the necessary activity from current activity
            //Everymethod in current activity is obtained using context






        }

    }
}