package com.likura.bookhub.database

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query

//This file is used to perform CURD operations
@Dao
interface BookDao {
     @Insert
    fun insertBook(bookEntity: BookEntity) //insert books into Data base

    @Delete
    fun deleteBook(bookEntity: BookEntity)  //deletes data from data base

    @Query("SELECT * FROM books")
    fun getAllBooks():List<BookEntity>

    @Query("SELECT * FROM books WHERE book_id= :bookId") //:bookId is used to tell compiler that id is obtained from function just below
    fun getBookById(bookId: String) : BookEntity //It checks if book is added to favs

    /* Here no body is specified because it is taken care by the Room library that is why we have made it a interface*/


}