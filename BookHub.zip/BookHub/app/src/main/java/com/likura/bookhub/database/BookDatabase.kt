package com.likura.bookhub.database

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [BookEntity::class],version=1) //version helps users when they make updates to app
abstract class BookDatabase :RoomDatabase() {

    abstract fun bookDao() : BookDao  //It serves as door way for all DAO operations

}