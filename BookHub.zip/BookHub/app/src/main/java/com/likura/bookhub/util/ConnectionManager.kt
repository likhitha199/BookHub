package com.likura.bookhub.util

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkInfo


class ConnectionManager {

    fun checkConnectivity(context: Context): Boolean
    {
        val connectivityManager =context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager  //gives information of currently active network
//Connectivty manager tells us if hardware of different types of connections wifi,mobile data,bluetooth etc is present or not
        val activeNetwork:NetworkInfo?= connectivityManager.activeNetworkInfo
        if(activeNetwork?.isConnected!=null)    //checks if network is connected to internet or not
        {
            return activeNetwork.isConnected
        }
        else
        {
            return false
        }
    }
}