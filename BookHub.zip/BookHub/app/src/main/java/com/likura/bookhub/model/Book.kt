package com.likura.bookhub.model
//used to create a data class
data class Book(
    val bookId: String,
    val bookName:String,
     val bookAuthor:String,
    val bookRating: String,
    val bookPrice:String,
    val bookImage: String
)

