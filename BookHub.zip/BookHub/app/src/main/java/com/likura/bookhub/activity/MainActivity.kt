package com.likura.bookhub.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.widget.FrameLayout
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.widget.Toolbar
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView
import com.likura.bookhub.*
import com.likura.bookhub.fragment.AboutFragment
import com.likura.bookhub.fragment.DashboardFragment
import com.likura.bookhub.fragment.FavouritesFragment
import com.likura.bookhub.fragment.ProfileFragment

class MainActivity : AppCompatActivity() {
    lateinit var drawerLayout: DrawerLayout     // creating varibales for storing id's views or layouts in activity_main.xml
    lateinit var coordinatorLayout: CoordinatorLayout
    lateinit var toolbar: Toolbar
    lateinit var frameLayout: FrameLayout
    lateinit var navigationView: NavigationView
    var previousMenuItem:MenuItem?=null  // It is used to check and uncheck menu items in navigation drawer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        drawerLayout=findViewById(R.id.drawerLayout)       // storing the views based on their ids
        coordinatorLayout=findViewById(R.id.coordinatorLayout)
        toolbar=findViewById(R.id.toolbar)
        frameLayout=findViewById(R.id.frameLayout)
        navigationView=findViewById(R.id.navigationView)
        setUpActionBar()    // calls action bar function to work
        //This allows us to create hamburger icon
        openDashboard()
        supportFragmentManager.beginTransaction()      // Dashboard opens as a default screen when app opens
            .replace(
                R.id.frameLayout,
                DashboardFragment()
            )
            .addToBackStack("DashBoard")
            .commit()
        supportActionBar?.title="DashBoard"

        val actionBarDrawerToggle = ActionBarDrawerToggle(this@MainActivity,
            drawerLayout, R.string.open_drawer
            , R.string.close_drawer
        )
        drawerLayout.addDrawerListener(actionBarDrawerToggle) //when clicked on hamburger icon drawer opens
        actionBarDrawerToggle.syncState() //hamburger icon changes to back arrow and vice versa

        navigationView.setNavigationItemSelectedListener {   //it provides functionality to items in navigational drawer
            if(previousMenuItem!=null)
            {
                previousMenuItem?.isChecked=false  // We uncheck the menu item if it is checked previously
            }
            it.isCheckable=true
            it.isChecked=true
            previousMenuItem=it // We make it unchecked when next item is pressed
            when(it.itemId)
            {
                R.id.dashboard ->{
                 openDashboard()
                    drawerLayout.closeDrawers() //closes navigation drawer on clicking dashboard menu item
                }
                R.id.favourites ->{
                    supportFragmentManager.beginTransaction()      //It begins start of DashBoardFragment
                        .replace(
                            R.id.frameLayout,
                            FavouritesFragment()
                        ) //It replaces activity_main with Dashboard fragment

                        .commit()
                    supportActionBar?.title="Favourites"
                    drawerLayout.closeDrawers() //closes navigation drawer on clicking dashboard menu item

                    //Toast.makeText(this@MainActivity,"Clicked on favs",Toast.LENGTH_SHORT).show()
                }
                R.id.profile ->{
                    supportFragmentManager.beginTransaction()      //It begins start of DashBoardFragment
                        .replace(
                            R.id.frameLayout,
                            ProfileFragment()
                        ) //It replaces activity_main with Dashboard fragment

                        .commit()
                    supportActionBar?.title="Profile"

                    drawerLayout.closeDrawers() //closes navigation drawer on clicking dashboard menu item
                    //Toast.makeText(this@MainActivity,"Clicked on profile",Toast.LENGTH_SHORT).show()
                }
                R.id.about ->{
                    supportFragmentManager.beginTransaction()      //It begins start of DashBoardFragment
                        .replace(
                            R.id.frameLayout,
                            AboutFragment()
                        ) //It replaces activity_main with Dashboard fragment

                        .commit()
                    supportActionBar?.title="About Us"
                    drawerLayout.closeDrawers() //closes navigation drawer on clicking dashboard menu item
                    //Toast.makeText(this@MainActivity,"Clicked on about",Toast.LENGTH_SHORT).show()
                }

            }
            return@setNavigationItemSelectedListener true
        }

    }
    fun setUpActionBar()
    {
       setSupportActionBar(toolbar)  //It sets up tool bar as the action bars
        supportActionBar?.title ="Book Hub" //It sets up name for the action bar
        supportActionBar?.setHomeButtonEnabled(true) // enables the home button (<--)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean { //item is hamburger icon (menuitem)
        val id= item.itemId  // extracts id of item
        if(id == android.R.id.home)   //checks if id extracted is same as hamburger icon
        {
            drawerLayout.openDrawer(GravityCompat.START)    //It opens the drawer from start of layout
        }
        return super.onOptionsItemSelected(item)
    }
    fun openDashboard()                      // Dashboard opens as a default screen when app opens
    {
        val fragment= DashboardFragment()
        val transaction =supportFragmentManager.beginTransaction()
        supportFragmentManager.beginTransaction() //It begins start of DashBoardFragment
            transaction.replace(R.id.frameLayout,fragment)  //It replaces activity_main with Dashboard fragment
        transaction.commit()
        supportActionBar?.title="DashBoard"  //sets the title of tool bar as per menu item clicked
        navigationView.setCheckedItem(R.id.dashboard)
    }

    override fun onBackPressed() {
        val frag=supportFragmentManager.findFragmentById(R.id.frameLayout)  //it holds  current fragment inside frame
        when(frag)
        {
            !is DashboardFragment ->openDashboard()
            else ->super.onBackPressed()
        }
    }
}
